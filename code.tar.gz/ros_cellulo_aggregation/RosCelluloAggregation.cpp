#include "ros_cellulo_aggregation/RosCelluloAggregation.hpp"
#include "tf2_ros/transform_listener.h"
#include "ros_cellulo_coverage/RosCelluloCoverage.hpp"
#include "stdlib.h"
#include "stdbool.h"



RosCelluloAggregation::RosCelluloAggregation(ros::NodeHandle& nodeHandle) : nodeHandle_(nodeHandle)
{
        if (!readParameters()) {

                ROS_ERROR("Could not read parameters :(.");
                ros::requestShutdown();
        }

        //subscribers
        subscriber_setThetaDis = nodeHandle_.subscribe(subscriberTopic_setThetaDis, 1, &RosCelluloAggregation::topicCallback_setThetaDis, this);

        nb_of_robots_detected=-1;
        nb_of_obstacles_detected=-1;
        velocity_updated=false;

}

RosCelluloAggregation::~RosCelluloAggregation(){
}



bool RosCelluloAggregation::readParameters()
{
        if (!nodeHandle_.getParam("thetaDis",ko))
            return false;
        else if(!nodeHandle_.getParam("scale", scale))
            return false;
        return true;
}

void RosCelluloAggregation::topicCallback_setThetaDis(const std_msgs::Float64 & message)
{
        thetaDis=message.data;
}

void RosCelluloAggregation::setPublishers()
{
    //publisher
    char publisherTopic_setvelocity[100];
    sprintf(publisherTopic_setvelocity, "/cellulo_node_%s/setGoalVelocity",RosCelluloAggregation::mac_Adr);
    publisher_Velocity = nodeHandle_.advertise<geometry_msgs::Vector3>(publisherTopic_setvelocity,1);

}

void RosCelluloAggregation::setSubscribers()
{
    //subscribers
    char subscriberTopicRobots[100],subscriberTopicObstacles[100],subscriberTopicVelocity[100];
    sprintf(subscriberTopicRobots, "/sensor_node_%s/detectedRobots",mac_Adr);

    sprintf(subscriberTopicObstacles, "/sensor_node_%s/detectedObstacles",mac_Adr);
    subscriber_Robots=nodeHandle_.subscribe(subscriberTopicRobots,1,&RosCelluloAggregation::topicCallback_getDetectedRobots,this);
    subscriber_Obstacles=nodeHandle_.subscribe(subscriberTopicObstacles,1,&RosCelluloAggregation::topicCallback_getDetectedObstacles,this);

    sprintf(subscriberTopicVelocity, "/cellulo_node_%s/velocity",mac_Adr);
    subscriber_Velocity= nodeHandle_.subscribe(subscriberTopicVelocity, 1, &RosCelluloAggregation::topicCallback_getVelocity,this);

}

void RosCelluloAggregation::topicCallback_getDetectedRobots(ros_cellulo_swarm::ros_cellulo_sensor sensor)
{
    distances_to_robots=sensor.Distance;
    nb_of_robots_detected=sensor.detected;
}

void RosCelluloAggregation::topicCallback_getDetectedObstacles(ros_cellulo_swarm::ros_cellulo_sensor sensor)
{
    distances_to_obstacles=sensor.Distance;
    nb_of_obstacles_detected=sensor.detected;

}

void RosCelluloAggregation::topicCallback_getVelocity(geometry_msgs::Vector3 v)
{
    RosCelluloAggregation::velocity.x=v.x;
    RosCelluloAggregation::velocity.y=v.y;
    RosCelluloAggregation::velocity_updated=true;  

}

geometry_msgs::Vector3 RosCelluloAggregation::randomWalk()
{
    int thetaDis = 180;

    double angle= rand() %(int)(360/thetaDis);
    angle*=thetaDis;
    int i=0;
    for (i=0; i<nb_of_robots_detected; i++)
    {
        if(distances_to_obstacles[i].z<100)
            angle=angle+90;
    }
        
    double velx = cos(angle)*100;
    double vely = sin(angle)*100;
    double velz = 0;

 
    geometry_msgs::Vector3 vel;
    vel.x=velx; vel.y= vely; vel.z= velz;

    return vel;
}

geometry_msgs::Vector3 RosCelluloAggregation::wait()
{
    double velx = 0;
    double vely = 0;
    double velz = 0;
    geometry_msgs::Vector3 vel;
    vel.x=velx; vel.y= vely; vel.z= velz;

   return vel;
}


void RosCelluloAggregation::naive_calculate_new_velocities()
{
    if(nb_of_robots_detected!=-1 && nb_of_obstacles_detected!=-1 && velocity_updated)
    {
        //*****************
        // FILL HERE - Part III Step 1
        //*****************

        int i=0;
            geometry_msgs::Vector3 vel;
        _Bool stop = false;
        for (i=0; i<nb_of_robots_detected; i++)
        {
            if(distances_to_robots[i].z < 100)
            {   
                vel = wait();
                stop = true;
            }
            else if(!stop)
                    vel = randomWalk();
        }

 ROS_INFO("velocity calcul %lf %lf",vel.x,vel.y);
    RosCelluloAggregation::publisher_Velocity.publish(vel);
    
        nb_of_robots_detected=-1;
        nb_of_obstacles_detected=-1;
        velocity_updated=false;
    }
    else
    {
        return;
    }
}


void RosCelluloAggregation::fourstates_calculate_new_velocities()
{
   
    if(nb_of_robots_detected!=-1 && nb_of_obstacles_detected!=-1 && velocity_updated)
    {
        //*****************
        // FILL HERE - Part III Step 2
        //*****************


        geometry_msgs::Vector3 vel;
        ROS_INFO("velocity calcul %lf %lf",vel.x,vel.y);
        RosCelluloAggregation::publisher_Velocity.publish(vel);

        nb_of_robots_detected=-1;
        nb_of_obstacles_detected=-1;
        velocity_updated=false;

    }
    else
    {
        return;
    }
}



double RosCelluloAggregation::norm(double x,double y)
{
        return sqrt(pow(x,2)+pow(y,2));
}

void RosCelluloAggregation::calculate_new_spot_velocities()
{
    double ks=100000;
    geometry_msgs::Vector3 Fo;
    geometry_msgs::Vector3 Fs;
    geometry_msgs::Vector3 Fn;
    geometry_msgs::Vector3 F;
    geometry_msgs::Vector3 distance_to_spot;
    geometry_msgs::Vector3 pos;
    geometry_msgs::Vector3 spot;


    //definir pos et spot 

    distance_to_spot.x=abs(pos.x-spot.x);
    distance_to_spot.y=abs(pos.y-spot.y);
    distance_to_spot.z=norm(distance_to_spot.x, distance_to_spot.y);

    double r = 0;
    //1- compute F
    double sumrx=0;
    double sumry=0;
    double sumox=0;
    double sumoy=0;
    int j=0; int k=0;
    for (j=0; j<nb_of_robots_detected; j++){
        r = distances_to_robots[j].z;
        if(r!= 0)
            sumrx+=(-1/(r*r))*(distances_to_robots[j].x/r);
        if(r!= 0)
            sumry+=(-1/(r*r))*(distances_to_robots[j].y/r);
    }
                
    Fo.x=kr*sumrx;
    Fo.y=kr*sumry;
    Fo.z=0;

    for (k=0; k<nb_of_obstacles_detected; k++)  
    {
        r = distances_to_obstacles[k].z;
        if(r!=0)
            sumox+=(-1/(r*r))*(distances_to_obstacles[k].x/r);
        if(r!=0)
            sumoy+=(-1/(r*r))*(distances_to_obstacles[k].y/r);
    }
            
    Fn.x=ko*sumox;
    Fn.y=ko*sumoy;
    Fn.z=0;

    r = distance_to_spot.z;
    if(r!=0)
        sumfx=(-1/(r*r))*(distance_to_spot.x/r);
    if(r!=0)
        sumfy=(-1/(r*r))*(distance_to_spot.y/r);
            
            
    Fs.x=-ks*sumfx;
    Fs.y=-ks*sumfy;
    Fs.z=0;
    F.x=Fo.x+Fn.x+Fs.x;
    F.y=Fo.y+Fn.y+Fs.y;
    F.z=Fo.z+Fn.z+Fs.z;
            
    //2- compute V 

    double dt=1/rate;

    vNew.x = vOld.x + dt*(F.x-mu*vOld.x)/m; 
    vNew.y = vOld.y + dt*(F.y-mu*vOld.y)/m;
    vNew.z=0;
    vOld.x = vNew.x;
    vOld.y = vNew.y;       
    // NB: you can use timestep=dt=1/rate.
    geometry_msgs::Vector3 vel;
    vel.x=vNew.x;
    vel.y=vNew.y;
    vel.z=vNew.z;
}
